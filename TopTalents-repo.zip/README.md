# TopTalents

Shows the talents most picked by top Warcraft Logs DPS parsers next to the in-game talent window.
Data is refreshed daily by GitHub Actions and published as a release.

## Install (players)
- **WowUp**: Get Addons -> Install from URL -> paste this repo's URL. Updates arrive automatically.
- **Manual**: download `TopTalents.zip` from the latest release, extract BOTH folders into `_retail_/Interface/AddOns/`.

## Setup (you, once)
1. Create a Warcraft Logs client: https://www.warcraftlogs.com/api/clients
2. Repo -> Settings -> Secrets and variables -> Actions:
   - Secrets: `WCL_CLIENT_ID`, `WCL_CLIENT_SECRET`
   - Variables: `WCL_ZONE_ID` (find with `python tools/fetch_wcl.py --list-zones`), optional `WCL_DIFFICULTY` (3/4/5)
3. Actions tab -> "Update talent data and release" -> Run workflow. After that it runs daily.
