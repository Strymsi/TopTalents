-- Placeholder. Overwritten daily by tools/fetch_wcl.py (GitHub Actions)
TopTalentsData = { updated = "never", specs = {} }
