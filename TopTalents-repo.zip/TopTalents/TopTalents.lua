local ADDON = ...
local ROW_H, MAX_ROWS = 22, 40
local panel

---------------------------------------------------------------------------
-- Which talent spellIDs does the player currently have?
---------------------------------------------------------------------------
local function GetOwnedTalentSpells()
    local owned = {}
    local configID = C_ClassTalents.GetActiveConfigID()
    if not configID then return owned end
    local cfg = C_Traits.GetConfigInfo(configID)
    if not cfg then return owned end

    for _, treeID in ipairs(cfg.treeIDs) do
        for _, nodeID in ipairs(C_Traits.GetTreeNodes(treeID)) do
            local node = C_Traits.GetNodeInfo(configID, nodeID)
            if node and node.activeEntry and node.activeRank and node.activeRank > 0 then
                local entry = C_Traits.GetEntryInfo(configID, node.activeEntry.entryID)
                local def = entry and entry.definitionID and C_Traits.GetDefinitionInfo(entry.definitionID)
                if def and def.spellID then owned[def.spellID] = true end
            end
        end
    end
    return owned
end

---------------------------------------------------------------------------
-- UI
---------------------------------------------------------------------------
local function CreateRow(parent, i)
    local row = CreateFrame("Frame", nil, parent)
    row:SetSize(220, ROW_H)
    row:SetPoint("TOPLEFT", 0, -(i - 1) * ROW_H)
    row:EnableMouse(true)

    row.icon = row:CreateTexture(nil, "ARTWORK")
    row.icon:SetSize(ROW_H - 2, ROW_H - 2)
    row.icon:SetPoint("LEFT", 0, 0)

    row.bar = CreateFrame("StatusBar", nil, row)
    row.bar:SetPoint("LEFT", row.icon, "RIGHT", 4, 0)
    row.bar:SetPoint("RIGHT", 0, 0)
    row.bar:SetHeight(ROW_H - 4)
    row.bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    row.bar:SetMinMaxValues(0, 100)

    row.name = row.bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.name:SetPoint("LEFT", 4, 0)
    row.name:SetJustifyH("LEFT")
    row.name:SetWidth(150)

    row.pct = row.bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.pct:SetPoint("RIGHT", -4, 0)

    row:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetSpellByID(self.spellID)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine(self.hasIt and "|cff33ff33You have this talent|r" or "|cffff5555You do not have this talent|r")
        GameTooltip:Show()
    end)
    row:SetScript("OnLeave", GameTooltip_Hide)
    return row
end

local function Refresh()
    if not panel or not panel:IsShown() then return end

    local specIndex = GetSpecialization()
    local specID, specName = GetSpecializationInfo(specIndex or 0)
    local data = specID and TopTalentsData.specs[specID]

    for _, r in ipairs(panel.rows) do r:Hide() end

    if not data then
        panel.title:SetText("Top DPS talents")
        panel.sub:SetText("No data for this spec.\nRun tools/fetch_wcl.py")
        return
    end

    panel.title:SetText(specName .. " – top DPS")
    panel.sub:SetText(("%d parses · updated %s"):format(data.sample or 0, TopTalentsData.updated or "?"))

    local owned = GetOwnedTalentSpells()
    for i, t in ipairs(data.talents) do
        if i > MAX_ROWS then break end
        local row = panel.rows[i] or CreateRow(panel.content, i)
        panel.rows[i] = row
        local info = C_Spell.GetSpellInfo(t.id)
        row.spellID = t.id
        row.hasIt = owned[t.id]
        row.icon:SetTexture(info and info.iconID or 134400)
        row.name:SetText(info and info.name or ("Spell " .. t.id))
        row.pct:SetText(("%d%%"):format(t.pct + 0.5))
        row.bar:SetValue(t.pct)
        if row.hasIt then
            row.bar:SetStatusBarColor(0.1, 0.6, 0.1, 0.8)
        else
            row.bar:SetStatusBarColor(0.6, 0.15, 0.15, 0.8)
        end
        row:Show()
    end
    panel.content:SetHeight(math.min(#data.talents, MAX_ROWS) * ROW_H)
end

local function BuildPanel()
    local parent = PlayerSpellsFrame
    panel = CreateFrame("Frame", "TopTalentsPanel", parent, "BasicFrameTemplateWithInset")
    panel:SetPoint("TOPLEFT", parent, "TOPRIGHT", 4, 0)
    panel:SetPoint("BOTTOMLEFT", parent, "BOTTOMRIGHT", 4, 0)
    panel:SetWidth(270)
    panel.rows = {}

    panel.title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    panel.title:SetPoint("TOP", 0, -5)

    panel.sub = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    panel.sub:SetPoint("TOPLEFT", 12, -30)
    panel.sub:SetJustifyH("LEFT")

    local scroll = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 10, -62)
    scroll:SetPoint("BOTTOMRIGHT", -30, 10)
    panel.content = CreateFrame("Frame", nil, scroll)
    panel.content:SetSize(225, 1)
    scroll:SetScrollChild(panel.content)

    panel:SetScript("OnShow", Refresh)
    panel:RegisterEvent("ACTIVE_PLAYER_SPECIALIZATION_CHANGED")
    panel:RegisterEvent("TRAIT_CONFIG_UPDATED")
    panel:SetScript("OnEvent", Refresh)
    Refresh()
end

EventUtil.ContinueOnAddOnLoaded("Blizzard_PlayerSpells", BuildPanel)

SLASH_TOPTALENTS1 = "/tt"
SlashCmdList.TOPTALENTS = function()
    if panel then panel:SetShown(not panel:IsShown()) end
end
