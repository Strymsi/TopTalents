#!/usr/bin/env python3
"""
Fetch top DPS talent picks from Warcraft Logs and write ../Data.lua

Setup:  pip install requests
        Create a client at https://www.warcraftlogs.com/api/clients
Usage:  (reads WCL_CLIENT_ID / WCL_CLIENT_SECRET from env if flags omitted)
        python fetch_wcl.py --client-id X --client-secret Y --list-zones
        python fetch_wcl.py --client-id X --client-secret Y --zone 46 --difficulty 5
"""
import argparse, os, sys, time
from collections import Counter
import requests

TOKEN_URL = "https://www.warcraftlogs.com/oauth/token"
API_URL = "https://www.warcraftlogs.com/api/v2/client"

# (WCL className, WCL specName, WoW specID)
SPECS = [
    ("DeathKnight", "Frost", 251), ("DeathKnight", "Unholy", 252),
    ("DemonHunter", "Havoc", 577), ("DemonHunter", "Devourer", 1480),  # verify Devourer ID
    ("Druid", "Balance", 102), ("Druid", "Feral", 103),
    ("Evoker", "Devastation", 1467), ("Evoker", "Augmentation", 1473),
    ("Hunter", "BeastMastery", 253), ("Hunter", "Marksmanship", 254), ("Hunter", "Survival", 255),
    ("Mage", "Arcane", 62), ("Mage", "Fire", 63), ("Mage", "Frost", 64),
    ("Monk", "Windwalker", 269),
    ("Paladin", "Retribution", 70),
    ("Priest", "Shadow", 258),
    ("Rogue", "Assassination", 259), ("Rogue", "Outlaw", 260), ("Rogue", "Subtlety", 261),
    ("Shaman", "Elemental", 262), ("Shaman", "Enhancement", 263),
    ("Warlock", "Affliction", 265), ("Warlock", "Demonology", 266), ("Warlock", "Destruction", 267),
    ("Warrior", "Arms", 71), ("Warrior", "Fury", 72),
]

def get_token(cid, secret):
    r = requests.post(TOKEN_URL, data={"grant_type": "client_credentials"}, auth=(cid, secret))
    r.raise_for_status()
    return r.json()["access_token"]

def gql(tok, query, variables=None):
    r = requests.post(API_URL, json={"query": query, "variables": variables or {}},
                      headers={"Authorization": f"Bearer {tok}"})
    r.raise_for_status()
    j = r.json()
    if "errors" in j:
        raise RuntimeError(j["errors"])
    return j["data"]

def list_zones(tok):
    d = gql(tok, "{worldData{zones{id name expansion{name}}}}")
    for z in d["worldData"]["zones"]:
        print(z["id"], z["name"], "-", z["expansion"]["name"])

def zone_encounters(tok, zone):
    d = gql(tok, "query($z:Int!){worldData{zone(id:$z){name encounters{id name}}}}", {"z": zone})
    return d["worldData"]["zone"]["encounters"]

RANK_Q = """query($id:Int!,$c:String!,$s:String!,$d:Int){worldData{encounter(id:$id){
characterRankings(className:$c,specName:$s,metric:dps,difficulty:$d)}}}"""

def ids_from_row(row):
    """Preferred: talents already embedded in the ranking row."""
    t = row.get("talents")
    if t:
        return {x["id"] for x in t if x.get("id")}
    return None

COMBATANT_Q = """query($c:String!,$f:Int!){reportData{report(code:$c){
masterData{actors(type:"Player"){id name}}
events(dataType:CombatantInfo,fightIDs:[$f],startTime:0,endTime:99999999999){data}}}}"""

def ids_from_report(tok, row):
    """Fallback: read CombatantInfo event of that fight (costs extra API points)."""
    rep = row.get("report") or {}
    if not rep.get("code"):
        return None
    d = gql(tok, COMBATANT_Q, {"c": rep["code"], "f": rep["fightID"]})["reportData"]["report"]
    actor = next((a for a in d["masterData"]["actors"] if a["name"] == row["name"]), None)
    if not actor:
        return None
    for ev in d["events"]["data"]:
        if ev.get("sourceID") == actor["id"]:
            return {t["id"] for t in ev.get("talentTree", []) if t.get("id")}
    return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--client-id", default=os.environ.get("WCL_CLIENT_ID"))
    ap.add_argument("--client-secret", default=os.environ.get("WCL_CLIENT_SECRET"))
    ap.add_argument("--zone", type=int)
    ap.add_argument("--difficulty", type=int, default=5, help="3 normal, 4 heroic, 5 mythic")
    ap.add_argument("--list-zones", action="store_true")
    ap.add_argument("--min-pct", type=float, default=5.0)
    ap.add_argument("--max-talents", type=int, default=40)
    ap.add_argument("--fallback-limit", type=int, default=15,
                    help="max report lookups per spec/boss when talents missing from rankings")
    ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "..", "TopTalentsData", "Data.lua"))
    a = ap.parse_args()

    if not a.client_id or not a.client_secret:
        sys.exit("Set WCL_CLIENT_ID and WCL_CLIENT_SECRET (or pass flags)")
    tok = get_token(a.client_id, a.client_secret)
    if a.list_zones:
        return list_zones(tok)
    if not a.zone:
        sys.exit("--zone required (use --list-zones)")

    encounters = zone_encounters(tok, a.zone)
    out = {}
    for cls, spec, spec_id in SPECS:
        counts, sample = Counter(), 0
        for enc in encounters:
            try:
                rk = gql(tok, RANK_Q, {"id": enc["id"], "c": cls, "s": spec, "d": a.difficulty})
                rows = rk["worldData"]["encounter"]["characterRankings"].get("rankings", [])
            except Exception as e:
                print(f"  ! {cls} {spec} {enc['name']}: {e}")
                continue
            fb = 0
            for row in rows:
                ids = ids_from_row(row)
                if ids is None and fb < a.fallback_limit:
                    fb += 1
                    ids = ids_from_report(tok, row)
                    time.sleep(0.2)
                if ids:
                    counts.update(ids)
                    sample += 1
        print(f"{cls} {spec}: {sample} parses")
        if sample:
            talents = [(i, 100 * c / sample) for i, c in counts.most_common()]
            talents = [t for t in talents if t[1] >= a.min_pct][: a.max_talents]
            out[spec_id] = (sample, talents)

    if not out:
        sys.exit("No data fetched - not overwriting Data.lua")

    with open(a.out, "w", encoding="utf-8") as f:
        f.write("-- Generated by tools/fetch_wcl.py\nTopTalentsData = {\n")
        f.write(f'    updated = "{time.strftime("%Y-%m-%d")}",\n    specs = {{\n')
        for sid, (n, tl) in out.items():
            f.write(f"        [{sid}] = {{ sample = {n}, talents = {{\n")
            for i, p in tl:
                f.write(f"            {{ id = {i}, pct = {p:.1f} }},\n")
            f.write("        } },\n")
        f.write("    },\n}\n")
    print("Wrote", os.path.abspath(a.out))

if __name__ == "__main__":
    main()
